<template>
  <div class="app-container">
    <h1 style="text-align:center">对不起, 当前功能暂未开发...</h1>
  </div>
</template>

<script>

</script>
